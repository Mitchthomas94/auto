export function GET() {
  const body = `User-agent: *\nAllow: /\nSitemap: https://autobookedai.co.uk/sitemap.xml`;
  return new Response(body, { headers: { "Content-Type": "text/plain" } });
}

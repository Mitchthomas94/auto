import Link from "next/link";

export const metadata = {
  title: "Terms & Conditions — AutoBooked AI",
  description: "Terms and conditions for using AutoBooked AI services."
};

export default function TermsPage() {
  return (
    <main className="container py-12 prose">
      <h1>Terms &amp; Conditions</h1>
      <p>Last updated: 20 August 2025</p>

      <h2>1. About us</h2>
      <p>AutoBooked AI (&quot;we&quot;, &quot;us&quot;, &quot;our&quot;) provides AI‑assisted appointment setting and related services.
      Contact: <a href="mailto:hello@autobookedai.co.uk">hello@autobookedai.co.uk</a>.</p>

      <h2>2. Services</h2>
      <p>We provide implementation and management of automated messaging workflows to qualify leads and book appointments.
      Specific deliverables will be set out in your order form or statement of work.</p>

      <h2>3. Fees & billing</h2>
      <p>Subscription fees are billed in advance monthly. Implementation fees, if any, are billed upon acceptance of the order.</p>

      <h2>4. Acceptable use</h2>
      <p>You agree not to use the services for unlawful, misleading, or unsolicited marketing in violation of applicable laws (e.g. PECR/GDPR, TCPA).
      You are responsible for your contact lists and end‑customer consents.</p>

      <h2>5. Data protection</h2>
      <p>Both parties will comply with applicable data protection laws including the UK GDPR. See our <Link href="/privacy">Privacy Policy</Link> for details.</p>

      <h2>6. Availability</h2>
      <p>We aim for high availability but do not guarantee uninterrupted service. We may perform maintenance with reasonable notice.</p>

      <h2>7. Intellectual property</h2>
      <p>We own all IP in our platform, playbooks, and configurations. You own your brand assets, data, and content.</p>

      <h2>8. Term & termination</h2>
      <p>Either party may terminate with 30 days’ written notice. No refunds for partial months unless required by law.</p>

      <h2>9. Limitation of liability</h2>
      <p>To the extent permitted by law, we exclude all implied warranties and limit liability to the fees paid in the preceding 12 months.</p>

      <h2>10. Governing law</h2>
      <p>These terms are governed by the laws of England and Wales. Courts of England shall have exclusive jurisdiction.</p>

      <p className="mt-8"><Link href="/" className="no-underline">&larr; Back to home</Link></p>
    </main>
  );
}

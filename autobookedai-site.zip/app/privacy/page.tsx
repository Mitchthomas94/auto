import Link from "next/link";

export const metadata = {
  title: "Privacy Policy — AutoBooked AI",
  description: "How AutoBooked AI collects, uses, and protects your data."
};

export default function PrivacyPage() {
  return (
    <main className="container py-12 prose">
      <h1>Privacy Policy</h1>
      <p>Last updated: 20 August 2025</p>

      <h2>1. Who we are</h2>
      <p>AutoBooked AI is the controller for personal data we process in connection with our website and services.
      Contact: <a href="mailto:hello@autobookedai.co.uk">hello@autobookedai.co.uk</a>.</p>

      <h2>2. What data we collect</h2>
      <ul>
        <li>Contact details (name, email, phone)</li>
        <li>Business information (company, role)</li>
        <li>Usage data and analytics (cookies/IP)</li>
        <li>Conversation transcripts required to deliver the service</li>
      </ul>

      <h2>3. How we use data</h2>
      <ul>
        <li>Provide and improve our services</li>
        <li>Book appointments and send confirmations</li>
        <li>Respond to enquiries and provide support</li>
        <li>Marketing with your consent or as permitted by law</li>
      </ul>

      <h2>4. Legal bases</h2>
      <p>Consent, contract performance, legitimate interests, and legal obligations.</p>

      <h2>5. Sharing</h2>
      <p>We share data with processors (e.g., hosting, analytics, messaging providers) under contract and confidentiality.</p>

      <h2>6. International transfers</h2>
      <p>Where data is transferred outside the UK/EEA, we use appropriate safeguards (e.g., SCCs).</p>

      <h2>7. Retention</h2>
      <p>We keep data only as long as needed for the purposes stated or as required by law.</p>

      <h2>8. Your rights</h2>
      <p>You can request access, correction, deletion, restriction, or portability. You can object to processing and withdraw consent anytime.</p>

      <h2>9. Cookies</h2>
      <p>We use essential and analytics cookies. You can control cookies via your browser settings.</p>

      <h2>10. Contact & complaints</h2>
      <p>Contact us at <a href="mailto:hello@autobookedai.co.uk">hello@autobookedai.co.uk</a>.
      You can also complain to the ICO (ico.org.uk).</p>

      <p className="mt-8"><Link href="/" className="no-underline">&larr; Back to home</Link></p>
    </main>
  );
}

import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "AutoBooked AI — Book more calls on autopilot",
  description: "Done-for-you AI appointment setting that converts missed calls and messages into booked calendar appointments.",
  metadataBase: new URL("https://autobookedai.co.uk"),
  openGraph: {
    title: "AutoBooked AI",
    description: "AI appointment setter that books calls 24/7",
    url: "https://autobookedai.co.uk",
    siteName: "AutoBooked AI",
  },
  alternates: {
    canonical: "/"
  }
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen flex flex-col">
        {children}
      </body>
    </html>
  );
}

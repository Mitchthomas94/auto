import Link from "next/link";

export default function CTA() {
  return (
    <section className="container py-16">
      <div className="rounded-2xl border border-gray-100 p-8 text-center shadow-sm">
        <h3 className="text-2xl font-bold">Ready to book more calls on autopilot?</h3>
        <p className="mt-2 text-gray-700">Click below and we’ll show you a live demo and rollout plan.</p>
        <Link href="https://calendly.com/autobookedai/intro-call" className="inline-block mt-6 px-6 py-3 rounded-xl bg-cyan-500 text-white font-medium hover:opacity-90">
          Book your demo
        </Link>
      </div>
    </section>
  );
}

export default function Pricing() {
  return (
    <section id="pricing" className="container py-16">
      <h2 className="text-3xl font-bold">Simple pricing</h2>
      <div className="grid md:grid-cols-3 gap-6 mt-8">
        <div className="rounded-2xl border border-gray-100 p-6 shadow-sm">
          <div className="text-sm font-medium text-gray-500">Starter</div>
          <div className="mt-2 text-3xl font-extrabold">£497<span className="text-base font-semibold">/mo</span></div>
          <ul className="mt-4 space-y-2 text-gray-700">
            <li>Up to 300 conversations</li>
            <li>WhatsApp + Web chat</li>
            <li>Calendar connection</li>
            <li>Email support</li>
          </ul>
        </div>
        <div className="rounded-2xl border-2 border-cyan-500 p-6 shadow-sm">
          <div className="text-sm font-medium text-cyan-600">Most popular</div>
          <div className="mt-2 text-3xl font-extrabold">£997<span className="text-base font-semibold">/mo</span></div>
          <ul className="mt-4 space-y-2 text-gray-700">
            <li>Up to 1,000 conversations</li>
            <li>WhatsApp + SMS + Web chat</li>
            <li>CRM integration</li>
            <li>Weekly optimization</li>
            <li>Priority support</li>
          </ul>
        </div>
        <div className="rounded-2xl border border-gray-100 p-6 shadow-sm">
          <div className="text-sm font-medium text-gray-500">Scale</div>
          <div className="mt-2 text-3xl font-extrabold">Custom</div>
          <ul className="mt-4 space-y-2 text-gray-700">
            <li>Unlimited conversations</li>
            <li>Multi‑location routing</li>
            <li>Dedicated manager</li>
            <li>SLA & custom reporting</li>
          </ul>
        </div>
      </div>
    </section>
  );
}

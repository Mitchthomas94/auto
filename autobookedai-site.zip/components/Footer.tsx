import Link from "next/link";

export default function Footer() {
  return (
    <footer className="mt-16 border-t border-gray-100">
      <div className="container py-8 text-sm text-gray-600 grid gap-4 md:grid-cols-3">
        <div>
          <div className="font-semibold">AutoBooked AI</div>
          <p className="mt-2">Book more calls. Miss fewer opportunities.</p>
        </div>
        <div className="flex gap-6">
          <div className="space-y-2">
            <div className="font-medium text-gray-800">Company</div>
            <ul className="space-y-2">
              <li><Link href="/terms" className="hover:underline">Terms & Conditions</Link></li>
              <li><Link href="/privacy" className="hover:underline">Privacy Policy</Link></li>
            </ul>
          </div>
          <div className="space-y-2">
            <div className="font-medium text-gray-800">Contact</div>
            <ul className="space-y-2">
              <li><a className="hover:underline" href="mailto:hello@autobookedai.co.uk">hello@autobookedai.co.uk</a></li>
            </ul>
          </div>
        </div>
        <div className="text-xs text-gray-500 md:text-right">© {new Date().getFullYear()} AutoBooked AI. All rights reserved.</div>
      </div>
    </footer>
  );
}

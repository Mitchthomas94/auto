import Link from "next/link";

export default function Hero() {
  return (
    <section className="container py-16 md:py-24">
      <div className="grid md:grid-cols-2 gap-8 items-center">
        <div>
          <h1 className="text-4xl md:text-5xl font-extrabold leading-tight">
            Turn missed calls & messages <span className="text-cyan-500">into booked appointments</span>
          </h1>
          <p className="mt-4 text-lg text-gray-700">
            We install and run an AI appointment setter that replies within seconds via WhatsApp, SMS, and web chat —
            qualifying leads and auto-booking into your calendar 24/7.
          </p>
          <div className="mt-6 flex gap-3">
            <Link href="https://calendly.com/autobookedai/intro-call" className="px-5 py-3 rounded-xl bg-cyan-500 text-white font-medium hover:opacity-90">
              Book a 15‑min intro call
            </Link>
            <a href="#how" className="px-5 py-3 rounded-xl border border-gray-300 font-medium hover:bg-gray-50">
              See how it works
            </a>
          </div>
          <p className="mt-3 text-xs text-gray-500">
            *Your Calendly will show “AutoBooked AI” as the meeting host.
          </p>
        </div>
        <div className="rounded-2xl border border-gray-100 p-6 shadow-sm">
          <div className="text-sm font-medium mb-2">Live preview</div>
          <div className="rounded-xl border border-gray-200 p-4">
            <div className="text-xs text-gray-500">WhatsApp • New message</div>
            <div className="mt-2 space-y-2 text-sm">
              <div className="bg-gray-100 rounded-lg p-3 w-fit">Hi! I missed your call — can we help you today?</div>
              <div className="bg-cyan-50 rounded-lg p-3 w-fit ml-auto">Yes, need a quote for boiler service.</div>
              <div className="bg-gray-100 rounded-lg p-3 w-fit">Great — what’s your postcode and availability?</div>
              <div className="bg-cyan-50 rounded-lg p-3 w-fit ml-auto">NG16 3AA, tomorrow afternoon.</div>
              <div className="bg-gray-100 rounded-lg p-3 w-fit">Perfect. Booking you for 2:30pm tomorrow. You’ll get a confirmation now ✅</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

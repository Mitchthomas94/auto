export default function HowItWorks() {
  const steps = [
    { step: "1", title: "Discovery call", desc: "We learn your offers, pricing, and booking rules." },
    { step: "2", title: "Setup & training", desc: "We connect your calendar, WhatsApp/SMS, and website chat." },
    { step: "3", title: "Go live", desc: "Missed calls & inbound messages turn into booked slots automatically." },
    { step: "4", title: "Optimize", desc: "We review transcripts and improve conversion weekly." }
  ];
  return (
    <section id="how" className="container py-16">
      <h2 className="text-3xl font-bold">How it works</h2>
      <div className="grid md:grid-cols-4 gap-6 mt-8">
        {steps.map((s) => (
          <div key={s.step} className="rounded-2xl border border-gray-100 p-6 shadow-sm">
            <div className="text-3xl font-extrabold text-cyan-500">{s.step}</div>
            <div className="mt-2 font-semibold">{s.title}</div>
            <p className="mt-2 text-gray-700">{s.desc}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

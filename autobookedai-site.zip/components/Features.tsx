export default function Features() {
  const items = [
    { title: "Instant replies", desc: "Under 30 seconds via WhatsApp/SMS/web chat." },
    { title: "Smart qualification", desc: "Collects key info automatically (name, service, budget, postcode)." },
    { title: "Calendar auto‑booking", desc: "Two‑way sync with your calendar to eliminate back‑and‑forth." },
    { title: "Human handoff", desc: "Flags hot leads for your team and posts to your CRM." },
    { title: "No‑show reduction", desc: "Automated reminders and rescheduling." },
    { title: "Fully managed", desc: "We set it up, train it on your FAQs, and optimize weekly." }
  ];
  return (
    <section id="features" className="container py-16">
      <h2 className="text-3xl font-bold">What you get</h2>
      <div className="grid md:grid-cols-3 gap-6 mt-8">
        {items.map((it) => (
          <div key={it.title} className="rounded-2xl border border-gray-100 p-6 shadow-sm">
            <div className="text-lg font-semibold">{it.title}</div>
            <p className="mt-2 text-gray-700">{it.desc}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

import Link from "next/link";

export default function Header() {
  return (
    <header className="border-b border-gray-100">
      <div className="container flex items-center justify-between py-4">
        <Link href="/" className="flex items-center gap-2 font-semibold">
          <svg width="28" height="28" viewBox="0 0 24 24" className="">
            <circle cx="12" cy="12" r="10" fill="#06b6d4" />
            <path d="M7 12h10M12 7v10" stroke="white" strokeWidth="2" strokeLinecap="round"/>
          </svg>
          AutoBooked AI
        </Link>
        <nav className="flex gap-6 text-sm">
          <Link href="#features" className="hover:opacity-80">Features</Link>
          <Link href="#how" className="hover:opacity-80">How it works</Link>
          <Link href="#pricing" className="hover:opacity-80">Pricing</Link>
          <Link href="https://calendly.com/autobookedai/intro-call" className="px-4 py-2 rounded-xl bg-cyan-500 text-white hover:opacity-90">
            Book a demo
          </Link>
        </nav>
      </div>
    </header>
  );
}

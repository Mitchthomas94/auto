# AutoBooked AI — Website

A clean Next.js 14 (App Router) site for **autobookedai.co.uk** with separate **Terms** and **Privacy** pages. Ready for Vercel.

## Quick start

```bash
# 1) Install deps
npm i

# 2) Run locally
npm run dev

# 3) Build
npm run build && npm start
```

## Deploy to Vercel

1. Create a new Git repo and push:

```bash
git init
git add .
git commit -m "Initial commit: AutoBooked AI site"
# Create a new repo on GitHub/GitLab/Bitbucket, then:
git branch -M main
git remote add origin <YOUR_REPO_URL>
git push -u origin main
```

2. In Vercel:
   - **New Project** → import your repository
   - Framework preset: **Next.js**
   - Build command: `next build` (auto)
   - Output: `.vercel/output/static` (auto-managed by Vercel)
   - Add your custom domain: **autobookedai.co.uk**

3. (Optional) Set the Calendly link in `components/Header.tsx` and `components/CTA.tsx` if you change it.

## Structure

- `app/page.tsx` — landing page
- `app/terms/page.tsx` — Terms & Conditions
- `app/privacy/page.tsx` — Privacy Policy
- `components/*` — UI sections
- `app/robots.txt/route.ts` & `app/sitemap.xml/route.ts` — SEO helpers
- `tailwind.config.ts` & `app/globals.css` — styling

## Customising legal pages

Edit the content in `app/terms/page.tsx` and `app/privacy/page.tsx`. For airtight compliance, have a solicitor review and tailor to your exact workflows (e.g., PECR/GDPR notices, DPA addendum if you process client data).

## Notes

- Designed to be lightweight with no server‑side code or databases.
- Uses Tailwind utility classes baked into a minimal design.
